﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Security.Cryptography;
using System.Threading;

class Server
{
    static Aes aes = Aes.Create();
    static TcpListener listener = new TcpListener(IPAddress.Any, 5000);

    static void Main()
    {
        listener.Start();
        Console.WriteLine("Server started...");
        while (true)
        {
            TcpClient client = listener.AcceptTcpClient();
            Thread thread = new Thread(() => HandleClient(client));
            thread.Start();
        }
    }

    static void HandleClient(TcpClient client)
    {
        NetworkStream stream = client.GetStream();
        byte[] buffer = new byte[1024];
        int byteCount = stream.Read(buffer, 0, buffer.Length);
        string encryptedMessage = Encoding.UTF8.GetString(buffer, 0, byteCount);
        string decryptedMessage = Decrypt(encryptedMessage);
        Console.WriteLine("Received: " + decryptedMessage);

        string response = "Hello from server!";
        string encryptedResponse = Encrypt(response);
        byte[] responseBytes = Encoding.UTF8.GetBytes(encryptedResponse);
        stream.Write(responseBytes, 0, responseBytes.Length);
        client.Close();
    }

    static string Encrypt(string plainText)
    {
        ICryptoTransform encryptor = aes.CreateEncryptor();
        byte[] input = Encoding.UTF8.GetBytes(plainText);
        byte[] encrypted = encryptor.TransformFinalBlock(input, 0, input.Length);
        return Convert.ToBase64String(encrypted);
    }

    static string Decrypt(string cipherText)
    {
        ICryptoTransform decryptor = aes.CreateDecryptor();
        byte[] input = Convert.FromBase64String(cipherText);
        byte[] decrypted = decryptor.TransformFinalBlock(input, 0, input.Length);
        return Encoding.UTF8.GetString(decrypted);
    }
}