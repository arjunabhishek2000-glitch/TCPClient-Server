﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

namespace Server
{

    internal class Program
    {
        static Dictionary<string, Dictionary<string, int>> serverCollection = new Dictionary<string, Dictionary<string, int>>()
        {
            {"SetA", new Dictionary<string, int>{{"One",1},{"Two",2}}},
            {"SetB", new Dictionary<string, int>{{"Three",3},{"Four",4}}},
            {"SetC", new Dictionary<string, int>{{"Five",5},{"Six",6}}},
            {"SetD", new Dictionary<string, int>{{"Seven",7},{"Eight",8}}},
            {"SetE", new Dictionary<string, int>{{"Nine",9},{"Ten",10}}}
        };

        static void Main(string[] args)
        {
            TcpListener server = new TcpListener(IPAddress.Any, 5000);
            server.Start();
            Console.WriteLine("Server started...");

            while (true)
            {
                TcpClient client = server.AcceptTcpClient();
                NetworkStream stream = client.GetStream();

                byte[] buffer = new byte[256];
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                string received = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                    // remove the code after testing
                    Console.WriteLine($"Received: {received}");

                string[] parts = received.Split('-');
                string set = parts[0];
                string key = parts.Length > 1 ? parts[1] : "";

                if (serverCollection.ContainsKey(set) && serverCollection[set].ContainsKey(key))
                {
                    int n = serverCollection[set][key];
                    for (int i = 0; i < n; i++)
                    {
                        string response = DateTime.Now.ToString("HH:mm:ss");
                        byte[] respBytes = Encoding.UTF8.GetBytes(response);
                        stream.Write(respBytes, 0, respBytes.Length);
                        Thread.Sleep(1000);
                    }
                }
                else
                {
                    byte[] respBytes = Encoding.UTF8.GetBytes("EMPTY");
                    stream.Write(respBytes, 0, respBytes.Length);
                }

                client.Close();
            }
        }
    }
}
